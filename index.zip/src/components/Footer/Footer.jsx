import React from "react";
import "./Footer.css"

function Footer(){
    return (
        <div className="footer">
            Copyright © 2024 CryptoFolio. All rights reserved.
        </div>
    )
}

export default Footer